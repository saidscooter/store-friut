const buyButtons = document.querySelectorAll('.buy-button');
const modal = document.getElementById('quantityModal');
const modalFruitName = document.getElementById('modalFruitName');
const quantityInput = document.getElementById('quantityInput');
const totalPriceDisplay = document.getElementById('totalPrice');
const confirmAdd = document.getElementById('confirmAdd');
const closeModal = document.querySelector('.close');
const cartItems = document.getElementById('cartItems');
const cartTotal = document.getElementById('cartTotal');

let selectedFruit = '';
let selectedPrice = 0;
let total = 0;

buyButtons.forEach(button => {
  button.addEventListener('click', () => {
    const fruitCard = button.closest('.fruit');
    selectedFruit = fruitCard.querySelector('h2').textContent;
    selectedPrice = parseFloat(fruitCard.querySelector('p').textContent.replace(/[^\d.]/g, ''));
    modalFruitName.textContent = `الفاكهة: ${selectedFruit}`;
    quantityInput.value = 1;
    updateTotalPrice();
    modal.style.display = 'block';
  });
});

quantityInput.addEventListener('input', updateTotalPrice);

function updateTotalPrice() {
  const quantity = parseInt(quantityInput.value) || 1;
  const totalPrice = (quantity * selectedPrice).toFixed(2);
  totalPriceDisplay.textContent = `الثمن الإجمالي: ${totalPrice}$`;
}

confirmAdd.addEventListener('click', () => {
  const quantity = parseInt(quantityInput.value);
  if (isNaN(quantity) || quantity < 1) return;
  const itemTotal = (quantity * selectedPrice).toFixed(2);
  const li = document.createElement('li');
  li.textContent = `${selectedFruit} × ${quantity} = ${itemTotal}$`;
  cartItems.appendChild(li);
  total += parseFloat(itemTotal);
  cartTotal.textContent = `المجموع: ${total.toFixed(2)}$`;
  modal.style.display = 'none';
});

closeModal.addEventListener('click', () => {
  modal.style.display = 'none';
});

window.addEventListener('click', (e) => {
  if (e.target === modal) {
    modal.style.display = 'none';
  }
});

function clearCart() {
  cartItems.innerHTML = '';
  total = 0;
  cartTotal.textContent = 'المجموع: 0.00$';
}
const fruits =[ 
   {
     name :" برتقال",
     Image: "../fruits/images/Orange-Fruit-Pieces.jpg",
     price: 11,
     link: "Orange.html",
   }

   {
    name :" موز",
    Image: "../fruits/images/Banana-Single.jpg",
    price: 11,
    link: "Banana.html",
  }

  {
    name:" تفاح",
    Image: "../fruits/images/Red_Apple.jpg",
    price: 11,
    link: "Appele.html",
  }

  {
    name :" فراولة",
    Image: "../fruits/images/strawberry.jpg",
    price: 11,
    link: "strawberry.html",
  }


];


